## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
# # Install if you haven't already
# # install.packages("devtools")
# devtools::install_github("gortegasolis/geomattR")
# 
# library(geomattR)
# library(terra)

## ----quick_start--------------------------------------------------------------
# # Create a simple polygon (1x1 degree square at equator)
# coords <- cbind(c(0, 0, 1, 1, 0), c(0, 1, 1, 0, 0))
# polygon <- vect(coords, type = "polygon", crs = "EPSG:4326")
# 
# # Calculate all available metrics
# result <- calculate_geometric_attributes(polygon)
# 
# # View the results
# print(result)
# 
# # Or view specific columns
# print(result[, c("area", "perimeter", "compactness")])

## ----size_metrics-------------------------------------------------------------
# # Calculate area and perimeter
# polygon_with_size <- calculate_geometric_attributes(
#   polygon,
#   metrics = c("area", "perimeter", "hole_area", "hole_area_pct")
# )
# 
# # Area in square meters (using geodesic calculations)
# print(polygon_with_size$area)
# 
# # Perimeter in meters
# print(polygon_with_size$perimeter)

## ----shape_metrics------------------------------------------------------------
# # Calculate shape characteristics
# polygon_with_shape <- calculate_geometric_attributes(
#   polygon,
#   metrics = c(
#     "compactness",           # Polsby-Popper (0-1, 1=perfect circle)
#     "reock",                 # Reock compactness
#     "shape_index",           # Dimensionless shape complexity
#     "circularity_ratio",     # Based on max length
#     "fractaldimension",      # Boundary complexity
#     "elongation_rectangle"   # Ratio of major to minor axis
#   )
# )
# 
# # Perfect circle has compactness = 1
# # Irregular shapes have lower values
# print(polygon_with_shape[, c("compactness", "shape_index")])

## ----orientation_metrics------------------------------------------------------
# # Calculate orientation
# polygon_with_orient <- calculate_geometric_attributes(
#   polygon,
#   metrics = c("bearing", "northerness", "ew_length", "ns_length", "maxlength")
# )
# 
# # Bearing: geographic direction of maximum length (south to north)
# print(polygon_with_orient$bearing)
# 
# # Northerness: cosine of bearing (-1=south, 0=east/west, 1=north)
# print(polygon_with_orient$northerness)
# 
# # Extents in meters (geodesic)
# print(paste("EW Extent:", round(polygon_with_orient$ew_length, 0), "m"))
# print(paste("NS Extent:", round(polygon_with_orient$ns_length, 0), "m"))

## ----complexity_metrics-------------------------------------------------------
# polygon_with_complexity <- calculate_geometric_attributes(
#   polygon,
#   metrics = c("sinuosity", "fractaldimension")
# )
# 
# # Sinuosity: perimeter / max_length (>1 indicates rougher boundary)
# print(polygon_with_complexity$sinuosity)
# 
# # Fractal dimension: measures boundary complexity (1-2)
# print(polygon_with_complexity$fractaldimension)

## ----geometry_metrics---------------------------------------------------------
# # Get centroid coordinates and structure info
# polygon_with_geom <- calculate_geometric_attributes(
#   polygon,
#   metrics = c(
#     "decimallongitude",
#     "decimallatitude",
#     "num_holes",
#     "num_polygons"
#   )
# )
# 
# print(polygon_with_geom[, c("decimallongitude", "decimallatitude")])

## ----multiple_polygons--------------------------------------------------------
# # Create multiple polygons
# coords1 <- cbind(c(0, 0, 1, 1, 0), c(0, 1, 1, 0, 0))
# coords2 <- cbind(c(1, 1, 2, 2, 1), c(1, 2, 2, 1, 1))
# 
# poly1 <- vect(coords1, type = "polygon", crs = "EPSG:4326")
# poly2 <- vect(coords2, type = "polygon", crs = "EPSG:4326")
# 
# # Combine into single SpatVector
# polygons <- rbind(poly1, poly2)
# 
# # Calculate metrics for all polygons at once
# results <- calculate_geometric_attributes(
#   polygons,
#   metrics = c("area", "perimeter", "compactness")
# )
# 
# # Results have same row count as input
# print(nrow(results))  # 2
# 
# # All metrics calculated
# print(results[, c("area", "perimeter", "compactness")])

## ----parallel-----------------------------------------------------------------
# library(parallel)
# 
# # Create multiple polygons
# polygons <- rbind(poly1, poly2)  # From previous example
# 
# # Set up cluster
# n_cores <- detectCores() - 1
# cl <- makeCluster(n_cores)
# 
# # Process in parallel
# results <- calculate_geometric_attributes_parallel(
#   polygons,
#   metrics = "all",
#   cl = cl
# )
# 
# # Clean up
# stopCluster(cl)
# 
# # Results are identical to sequential processing
# print(head(results))

## ----crs_handling-------------------------------------------------------------
# # Create polygon in geographic CRS (WGS84/EPSG:4326)
# poly_geographic <- vect(coords1, type = "polygon", crs = "EPSG:4326")
# 
# # Create same polygon in projected CRS (UTM Zone 30N)
# poly_projected <- project(poly_geographic, "EPSG:32630")
# 
# # Calculate metrics on both
# result_geo <- calculate_geometric_attributes(poly_geographic, metrics = "area")
# result_proj <- calculate_geometric_attributes(poly_projected, metrics = "area")
# 
# # Both should give similar results (using geodesic calculations)
# print(paste("Geographic CRS area:", round(result_geo$area, 0), "m²"))
# print(paste("Projected CRS area:", round(result_proj$area, 0), "m²"))
# 
# # Difference should be minimal due to geodesic calculations
# print(paste(
#   "Difference:",
#   round(abs(result_geo$area - result_proj$area), 0),
#   "m²"
# ))

## ----building_example---------------------------------------------------------
# # Load building footprints (example structure)
# # buildings <- vect("path/to/buildings.shp")
# 
# # For this example, create synthetic building data
# set.seed(42)
# n_buildings <- 10
# angles <- seq(0, 2*pi, length.out = n_buildings + 1)[-n_buildings-1]
# 
# buildings_list <- lapply(angles, function(angle) {
#   center_x <- cos(angle) * 5
#   center_y <- sin(angle) * 5
#   size <- runif(1, 0.5, 2)
# 
#   cbind(
#     center_x + size * c(0, size, size, 0, 0),
#     center_y + size * c(0, 0, size, size, 0)
#   )
# })
# 
# buildings <- vect(buildings_list, type = "polygon", crs = "EPSG:4326")
# 
# # Calculate comprehensive metrics
# building_metrics <- calculate_geometric_attributes(
#   buildings,
#   metrics = c(
#     "area",
#     "perimeter",
#     "compactness",
#     "elongation_rectangle",
#     "shape_index"
#   )
# )
# 
# # Analyze results
# print("Building Metrics Summary:")
# print(summary(building_metrics$area))
# print(summary(building_metrics$compactness))
# 
# # Identify compact vs. elongated buildings
# print("\nCompact buildings (compactness > 0.7):")
# compact <- building_metrics[building_metrics$compactness > 0.7, ]
# print(paste(nrow(compact), "buildings"))
# 
# print("\nElongated buildings (elongation > 2.0):")
# elongated <- building_metrics[building_metrics$elongation_rectangle > 2.0, ]
# print(paste(nrow(elongated), "buildings"))

## ----advanced-----------------------------------------------------------------
# # Complete workflow for polygon analysis
# process_polygons <- function(polygons, min_area = 1000) {
#   # Calculate all metrics
#   results <- calculate_geometric_attributes(polygons, metrics = "all")
# 
#   # Filter by size
#   results <- results[results$area >= min_area, ]
# 
#   # Add derived metrics
#   results$perimeter_to_area <- results$perimeter / results$area
#   results$is_compact <- results$compactness > 0.7
#   results$is_elongated <- results$elongation_rectangle > 2.0
# 
#   return(results)
# }
# 
# # Use the function
# analyzed_buildings <- process_polygons(buildings, min_area = 5000)
# print(head(analyzed_buildings))

## ----performance--------------------------------------------------------------
# # For 100,000+ polygons, parallel processing is recommended
# cl <- makeCluster(detectCores() - 1)
# results <- calculate_geometric_attributes_parallel(
#   large_polygon_set,
#   metrics = "all",
#   cl = cl
# )
# stopCluster(cl)

